<?php
// register.php
header('Content-Type: application/json');

$uname1 = trim($_POST['uname1']  ?? '');
$email  = trim($_POST['email']   ?? '');
$mobile = trim($_POST['mobile']  ?? '');
$upswd1 = trim($_POST['upswd1']  ?? '');
$upswd2 = trim($_POST['upswd2']  ?? '');

if (empty($uname1) || empty($email) || empty($mobile) || empty($upswd1) || empty($upswd2)) {
    echo json_encode(["status" => "error", "message" => "All fields are required"]);
    exit;
}

if ($upswd1 !== $upswd2) {
    echo json_encode(["status" => "error", "message" => "Passwords do not match"]);
    exit;
}

if (!preg_match('/^\d{10}$/', $mobile)) {
    echo json_encode(["status" => "error", "message" => "Enter a valid 10-digit mobile number"]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "bitebychoice");

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

// Check duplicate email
$stmt = $conn->prepare("SELECT email FROM register WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "This email is already registered"]);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// Insert new user with hashed password
$hashed = password_hash($upswd1, PASSWORD_DEFAULT);
$stmt   = $conn->prepare("INSERT INTO register (uname1, email, mobile, upswd1) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $uname1, $email, $mobile, $hashed);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Account created! Redirecting to login..."]);
} else {
    echo json_encode(["status" => "error", "message" => "Registration failed. Please try again."]);
}

$stmt->close();
$conn->close();
?>