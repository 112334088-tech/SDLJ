<?php
// order_customer.php
// Returns customer details for the currently logged-in user (session-based)
header('Content-Type: application/json');
session_start();

// If you store the logged-in username in session after login.php, use it here.
// Adjust the session key to match what login.php sets.
$uname = $_SESSION['uname1'] ?? ($_GET['uname'] ?? '');

if (empty($uname)) {
    echo json_encode(["status" => "error", "message" => "Not logged in"]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "bitebychoice");

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

$stmt = $conn->prepare("SELECT uname1, email, mobile FROM register WHERE uname1 = ? LIMIT 1");
$stmt->bind_param("s", $uname);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        "status"  => "success",
        "uname1"  => $row['uname1'],
        "email"   => $row['email'],
        "mobile"  => $row['mobile']
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "User not found"]);
}

$stmt->close();
$conn->close();
?>