<?php
// ============================================================
//  get_orders.php  –  fetches orders + updates status
//  Place in:  C:/xampp/htdocs/bitebychoice/
// ============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

session_start();

// ── DB CONFIG ──────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bitebychoice');

// ── CONNECT ───────────────────────────────────────────────
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'DB connection failed: ' . $conn->connect_error]);
    exit;
}
$conn->set_charset('utf8mb4');

$action = $_GET['action'] ?? 'list';

// ────────────────────────────────────────────────────────────
//  ACTION: list  –  return orders (admin: all | user: own)
// ────────────────────────────────────────────────────────────
if ($action === 'list') {
    $status = $_GET['status'] ?? 'all';
    $search = $conn->real_escape_string(trim($_GET['search'] ?? ''));

    // Determine if request is from admin panel or a logged-in customer
    // Admin panel passes ?admin=1; customer orders page relies on session
    $is_admin   = isset($_GET['admin']) && $_GET['admin'] === '1';
    $session_uname = $_SESSION['uname1'] ?? '';

    $where = [];

    // Non-admin: restrict to own orders via JOIN on register
    if (!$is_admin && $session_uname) {
        $uname_esc = $conn->real_escape_string($session_uname);
        $where[] = "r.uname1 = '$uname_esc'";
    }

    if ($status !== 'all') {
        $s       = $conn->real_escape_string($status);
        $where[] = "o.status = '$s'";
    }

    if ($search) {
        $where[] = "(o.customer LIKE '%$search%' OR o.food_summary LIKE '%$search%' OR o.order_id LIKE '%$search%')";
    }

    $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    // LEFT JOIN register so admin sees even guest orders (user_id = NULL)
    $sql = "SELECT
                o.id, o.order_id, o.user_id,
                o.customer, o.phone, o.address,
                o.food_items, o.food_summary,
                o.qty, o.amount, o.status,
                DATE_FORMAT(o.created_at, '%Y-%m-%d %H:%i') AS date,
                r.email
            FROM orders o
            LEFT JOIN register r ON r.id = o.user_id
            $whereClause
            ORDER BY o.created_at DESC";

    $result = $conn->query($sql);
    if (!$result) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $conn->error]);
        exit;
    }

    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $row['food_items'] = json_decode($row['food_items'], true) ?? [];
        $orders[] = $row;
    }

    // Stats (always across all orders for admin dashboard)
    $statsResult = $conn->query("SELECT
        COUNT(*)                                           AS total,
        SUM(status = 'Pending')                           AS pending,
        SUM(status = 'Completed')                         AS completed,
        SUM(CASE WHEN status='Completed' THEN amount ELSE 0 END) AS revenue
        FROM orders");
    $stats = $statsResult->fetch_assoc();

    echo json_encode([
        'success' => true,
        'orders'  => $orders,
        'stats'   => [
            'total'     => (int)   $stats['total'],
            'pending'   => (int)   $stats['pending'],
            'completed' => (int)   $stats['completed'],
            'revenue'   => (float) $stats['revenue']
        ]
    ]);

// ────────────────────────────────────────────────────────────
//  ACTION: update_status  –  POST { order_id, status }
// ────────────────────────────────────────────────────────────
} elseif ($action === 'update_status') {
    $raw  = file_get_contents('php://input');
    $data = json_decode($raw, true);

    $allowed  = ['Pending', 'Completed', 'Cancelled'];
    $order_id = $conn->real_escape_string(trim($data['order_id'] ?? ''));
    $status   = $data['status'] ?? '';

    if (!$order_id || !in_array($status, $allowed)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid order_id or status']);
        exit;
    }

    $sql = "UPDATE orders SET status='$status', updated_at=NOW() WHERE order_id='$order_id'";
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'affected' => $conn->affected_rows]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }

// ────────────────────────────────────────────────────────────
//  ACTION: me  –  returns current session user info
//          (used by order.html to pre-fill customer details)
// ────────────────────────────────────────────────────────────
} elseif ($action === 'me') {
    $uname = $_SESSION['uname1'] ?? '';
    if (!$uname) {
        echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
        exit;
    }

    $stmt = $conn->prepare("SELECT uname1, email, mobile FROM register WHERE uname1 = ? LIMIT 1");
    $stmt->bind_param("s", $uname);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row) {
        echo json_encode(['status' => 'success', 'uname1' => $row['uname1'],
                          'email' => $row['email'], 'mobile' => $row['mobile']]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'User not found']);
    }

} else {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => "Unknown action: $action"]);
}

$conn->close();
?>
