// script.js

// ---------- LOGIN ----------
function login() {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const errorMsg = document.getElementById("errorMsg");

    errorMsg.style.color = "red";

    if (!username || !password) {
        errorMsg.textContent = "All fields are required";
        return;
    }

    // ── Admin shortcut (no server call needed) ──
    if (username === "Admin" && password === "Tharun@18") {
        errorMsg.style.color = "lightgreen";
        errorMsg.textContent = "Welcome, Admin! Redirecting...";
        setTimeout(() => { window.location.href = "admin.html"; }, 1000);
        return;
    }

    // ── Normal user login via PHP ──
    const formData = new FormData();
    formData.append("uname1", username);
    formData.append("upswd1", password);

    fetch("login.php", { method: "POST", body: formData })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                // Store customer details in sessionStorage for order page
                sessionStorage.setItem('bbcUser', JSON.stringify({
                    uname1 : data.uname1  || username,
                    email  : data.email   || '',
                    mobile : data.mobile  || ''
                }));
                errorMsg.style.color = "lightgreen";
                errorMsg.textContent = data.message;
                setTimeout(() => { window.location.href = "food-website.html"; }, 1000);
            } else {
                errorMsg.textContent = data.message;
            }
        })
        .catch(() => { errorMsg.textContent = "Server error. Please try again."; });
}

// ---------- FORGOT PASSWORD ----------
function forgotPassword() {
    alert("Please contact support to reset your password.");
}

// ---------- REGISTER ----------
function register() {
    const username        = document.getElementById("regUsername").value.trim();
    const email           = document.getElementById("regEmail").value.trim();
    const mobile          = document.getElementById("regmobile").value.trim();
    const password        = document.getElementById("regPassword").value.trim();
    const confirmPassword = document.getElementById("regConfirmPassword").value.trim();
    const errorMsg        = document.getElementById("regError");
    const successMsg      = document.getElementById("regSuccess");

    errorMsg.textContent   = "";
    successMsg.textContent = "";

    if (!username || !email || !mobile || !password || !confirmPassword) {
        errorMsg.textContent = "All fields are required";
        return;
    }

    if (username.length < 6) {
        errorMsg.textContent = "Username must be at least 6 characters";
        return;
    }

    if (!/^[a-z0-9._%+\-]+@gmail\.com$/.test(email)) {
        errorMsg.textContent = "Email must be a valid lowercase Gmail address (e.g. name@gmail.com)";
        return;
    }

    if (!/^\d{10}$/.test(mobile)) {
        errorMsg.textContent = "Enter a valid 10-digit mobile number";
        return;
    }

    if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password) || !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]/.test(password)) {
        errorMsg.textContent = "Password must be 8+ characters with a letter, number, and special character";
        return;
    }

    if (password !== confirmPassword) {
        errorMsg.textContent = "Passwords do not match";
        return;
    }

    const formData = new FormData();
    formData.append("uname1", username);
    formData.append("email",  email);
    formData.append("mobile", mobile);
    formData.append("upswd1", password);
    formData.append("upswd2", confirmPassword);

    fetch("register.php", { method: "POST", body: formData })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                successMsg.style.color = "lightgreen";
                successMsg.textContent = data.message;
                setTimeout(() => { window.location.href = "index.html"; }, 1500);
            } else {
                errorMsg.textContent = data.message;
            }
        })
        .catch(() => { errorMsg.textContent = "Server error. Please try again."; });
}