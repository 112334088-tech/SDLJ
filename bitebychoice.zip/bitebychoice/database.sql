-- ============================================
-- Run this ONCE in phpMyAdmin → SQL tab
-- ============================================

CREATE DATABASE IF NOT EXISTS bitebychoice;

USE bitebychoice;

CREATE TABLE IF NOT EXISTS register (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    uname1     VARCHAR(50)  NOT NULL,
    email      VARCHAR(100) NOT NULL UNIQUE,
    mobile     VARCHAR(15)  NOT NULL,
    upswd1     VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
