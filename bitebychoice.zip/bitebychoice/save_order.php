<?php
// ============================================================
//  save_order.php  –  receives order from order.html
//  Place in:  C:/xampp/htdocs/bitebychoice/
// ============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// Start session so we can read login.php's session values
session_start();

// ── DB CONFIG ──────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bitebychoice');

// ── CONNECT ───────────────────────────────────────────────
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'DB connection failed: ' . $conn->connect_error]);
    exit;
}
$conn->set_charset('utf8mb4');

// ── READ INPUT ────────────────────────────────────────────
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON body']);
    exit;
}

// ── VALIDATE REQUIRED FIELDS ──────────────────────────────
$required = ['order_id', 'address', 'food_items', 'food_summary', 'qty', 'amount'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => "Missing field: $field"]);
        exit;
    }
}

// ── RESOLVE CUSTOMER FROM SESSION (set by login.php) ──────
//    Session keys used by login.php: uname1, email, mobile
$session_uname = $_SESSION['uname1'] ?? '';
$user_id       = null;
$customer      = '';
$phone         = '';

if ($session_uname) {
    // Logged-in user: pull fresh details + register.id from DB
    $stmt = $conn->prepare("SELECT id, uname1, mobile FROM register WHERE uname1 = ? LIMIT 1");
    $stmt->bind_param("s", $session_uname);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row) {
        $user_id  = (int) $row['id'];
        $customer = $row['uname1'];
        $phone    = $row['mobile'];
    }
} else {
    // Guest / not logged in: use whatever the front-end sent
    $customer = trim($data['customer'] ?? 'Guest');
    $phone    = trim($data['phone']    ?? '');
}

if (empty($customer)) { $customer = 'Guest'; }

// ── SANITIZE & PREPARE ────────────────────────────────────
$order_id     = $conn->real_escape_string(trim($data['order_id']));
$address      = $conn->real_escape_string(trim($data['address']));
$food_items   = $conn->real_escape_string(json_encode($data['food_items']));
$food_summary = $conn->real_escape_string(trim($data['food_summary']));
$qty          = (int)   $data['qty'];
$amount       = (float) $data['amount'];
$customer_esc = $conn->real_escape_string($customer);
$phone_esc    = $conn->real_escape_string($phone);
$user_id_sql  = $user_id !== null ? $user_id : 'NULL';

// ── INSERT ────────────────────────────────────────────────
$sql = "INSERT INTO orders
            (order_id, user_id, customer, phone, address, food_items, food_summary, qty, amount, status, created_at)
        VALUES
            ('$order_id', $user_id_sql, '$customer_esc', '$phone_esc', '$address',
             '$food_items', '$food_summary', $qty, $amount, 'Pending', NOW())";

if ($conn->query($sql)) {
    echo json_encode([
        'success'  => true,
        'message'  => 'Order saved successfully',
        'order_id' => $order_id,
        'db_id'    => $conn->insert_id
    ]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Insert failed: ' . $conn->error]);
}

$conn->close();
?>
