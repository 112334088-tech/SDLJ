<?php
// login.php
header('Content-Type: application/json');
session_start();

$uname1 = trim($_POST['uname1'] ?? '');
$upswd1 = trim($_POST['upswd1'] ?? '');

if (empty($uname1) || empty($upswd1)) {
    echo json_encode(["status" => "error", "message" => "All fields are required"]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "bitebychoice");

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

$stmt = $conn->prepare("SELECT uname1, email, mobile, upswd1 FROM register WHERE uname1 = ? LIMIT 1");
$stmt->bind_param("s", $uname1);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    if (password_verify($upswd1, $row['upswd1'])) {
        // Set PHP session
        $_SESSION['uname1'] = $row['uname1'];
        $_SESSION['email']  = $row['email'];
        $_SESSION['mobile'] = $row['mobile'];

        echo json_encode([
            "status"  => "success",
            "message" => "Login successful! Redirecting...",
            "uname1"  => $row['uname1'],
            "email"   => $row['email'],
            "mobile"  => $row['mobile']
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Incorrect password"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Username not found"]);
}

$stmt->close();
$conn->close();
?>